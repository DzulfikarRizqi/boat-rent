﻿using System;
using System.Data;
using System.Threading.Tasks;
using Npgsql;
using CobaHW7.Class;

namespace CobaHW7.Data
{
    public class UserRepository
    {
        private const string PasswordColumn = "password";

        public async Task<bool> EmailExistsAsync(string email)
        {
            using var con = Db.GetOpenConnection();
            using var cmd = new NpgsqlCommand(
                "SELECT 1 FROM users WHERE lower(btrim(email)) = lower(btrim(@e)) LIMIT 1;", con);
            cmd.Parameters.AddWithValue("@e", email ?? "");
            using var rd = await cmd.ExecuteReaderAsync();
            return await rd.ReadAsync();
        }

        public async Task<int> CreateAsync(User u)
        {
            using var con = Db.GetOpenConnection();
            using var cmd = new NpgsqlCommand($@"
                INSERT INTO users(name, email, {PasswordColumn}, is_admin)
                VALUES(@n, @e, @p, @a)
                RETURNING id;", con);

            cmd.Parameters.AddWithValue("@n", u.Name ?? "");
            cmd.Parameters.AddWithValue("@e", u.Email ?? "");
            cmd.Parameters.AddWithValue("@p", u.Password ?? "");   // TODO: ganti ke hash kalau siap
            cmd.Parameters.AddWithValue("@a", u.IsAdmin);

            try
            {
                var idObj = await cmd.ExecuteScalarAsync();
                return Convert.ToInt32(idObj);
            }
            catch (PostgresException ex) when (ex.SqlState == "23505") // unique_violation
            {
                throw new DuplicateNameException("EMAIL_TAKEN");
            }
        }

        public async Task<User?> FindByEmailAsync(string email)
        {
            using var con = Db.GetOpenConnection();
            using var cmd = new NpgsqlCommand($@"
                SELECT id, name, email, {PasswordColumn}, COALESCE(is_admin,false)
                FROM users
                WHERE lower(btrim(email)) = lower(btrim(@e))
                LIMIT 1;", con);
            cmd.Parameters.AddWithValue("@e", email ?? "");

            using var rd = await cmd.ExecuteReaderAsync();
            if (!await rd.ReadAsync()) return null;

            return new User
            {
                Id = rd.GetInt32(0),
                Name = rd.IsDBNull(1) ? "" : rd.GetString(1),
                Email = rd.IsDBNull(2) ? "" : rd.GetString(2),
                Password = rd.IsDBNull(3) ? "" : rd.GetString(3),
                IsAdmin = rd.GetBoolean(4)
            };
        }
    }
}
