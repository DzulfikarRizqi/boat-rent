﻿using System.Windows;
using CobaHW7.Data;

namespace CobaHW7
{
    public partial class MainWindow : Window
    {
        private readonly UserRepository _repo = new UserRepository();

        public MainWindow()
        {
            InitializeComponent();
        }

        private async void SignInButton_Click(object sender, RoutedEventArgs e)
        {
            var email = EmailTextBox.Text?.Trim();   // ← pakai email
            var password = PasswordBox.Password;

            if (string.IsNullOrWhiteSpace(email) || string.IsNullOrWhiteSpace(password))
            {
                DialogService.Info("Form belum lengkap", "Email dan password wajib diisi.");
                return;
            }

            var user = await _repo.FindByEmailAsync(email);
            if (user is null)
            {
                DialogService.Info("Akun tidak ditemukan", "Email belum terdaftar. Silakan registrasi dulu.");
                return;
            }

            // TODO: ganti ke verifikasi hash jika sudah hash
            var ok = string.Equals(user.Password, password);
            if (!ok)
            {
                DialogService.Error("Password salah", "Kata sandi tidak cocok. Coba lagi ya.");
                return;
            }

            DialogService.Success("Login berhasil", $"Selamat datang, {user.Name}!");

            if (user.IsAdmin)
            {
                var win = new DashboardAdmin { Owner = this };
                win.Show();
            }
            else
            {
                var win = new Dashboard(user) { Owner = this };
                win.Show();
            }
            Close();
        }

        private void RegisterHyperlink_Click(object sender, RoutedEventArgs e)
        {
            var reg = new RegisterWindow { Owner = this };
            reg.Show();
            Close();
        }
    }
}
