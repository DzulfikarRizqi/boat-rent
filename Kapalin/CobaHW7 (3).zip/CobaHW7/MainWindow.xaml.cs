﻿using System.Windows;
using CobaHW7.Data;

namespace CobaHW7
{
    public partial class MainWindow : Window
    {
        private readonly UserRepository _repo = new UserRepository();

        private void RegisterHyperlink_Click(object sender, RoutedEventArgs e)
        {
            var reg = new RegisterWindow { Owner = this };
            reg.Show();
            this.Close();
        }

        private async void SignInButton_Click(object sender, RoutedEventArgs e)
        {
            var ident = (NameTextBox.Text ?? "").Trim();    // username atau email
            var pass = (PasswordBox.Password ?? "").Trim();

            if (string.IsNullOrWhiteSpace(ident) || string.IsNullOrWhiteSpace(pass))
            {
                DialogService.Info("Form belum lengkap", "Isi username/email dan password.");
                return;
            }

            var user = await _repo.GetByLoginAsync(ident);
            if (user is null)
            {
                DialogService.Info("Akun tidak ditemukan", "Periksa lagi username/email atau daftar dulu.");
                return;
            }

            if (!_repo.VerifyPassword(user, pass))
            {
                DialogService.Error("Password salah", "Kata sandi tidak cocok. Coba lagi ya.");
                return;
            }

            DialogService.Success("Login berhasil", $"Selamat datang, {user.Name}!");
            if (user.IsAdmin) new DashboardAdmin { Owner = this }.Show();
            else new Dashboard(user) { Owner = this }.Show();
            Close();
        }

    }
}
